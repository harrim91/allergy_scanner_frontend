angular.module('happyBellyApp')
  .controller('UserController', function($scope, $auth, $state, $rootScope){

    var self = this;

    function setUser(user) {
      localStorage.setItem('user', user);
    }

    function getUser() {
      localStorage.getItem('user');
    }

    $scope.handleRegBtnClick = function() {
      $auth.submitRegistration($scope.registrationForm)
        .then(function() {
          $state.go('search');
        })
        .catch(function(resp) {
        console.log(resp);
        });
    };

    $scope.handleLoginBtnClick = function(loginForm) {
      $auth.submitLogin(loginForm)
        .then(function() {
          $state.go('search');
        })
        .catch(function(resp) {
          console.log(resp);
        });
    };

    $scope.handleSignOutBtnClick = function() {
      $auth.signOut().then(function() {
        $state.go('sign_in');
        console.log(self.currentUser);
      });
    };

    $rootScope.$on('auth:login-success', function(ev, user) {
     setUser(user);
     alert('Welcome ', getUser().email);
   });



   $scope.$on('devise:new-registration', function (e, user){
     $scope.user = user;
   });

   $scope.$on('devise:login', function (e, user){
     $scope.user = user;
   });

   console.log($scope.user);
  });
